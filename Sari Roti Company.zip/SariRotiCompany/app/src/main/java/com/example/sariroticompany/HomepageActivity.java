package com.example.sariroticompany;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListView;

public class HomepageActivity extends AppCompatActivity {
    String[] judul;
    String[] ket;
    TypedArray gambar;
    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        lv = findViewById(R.id.lvData);

        judul = getResources().getStringArray(R.array.array_judul);
        ket = getResources().getStringArray(R.array.arary_ket);
        gambar = getResources().obtainTypedArray(R.array.array_logo);


        lvAdapter adapter = new lvAdapter(this, judul, ket, gambar);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0) {
                    Intent j = new Intent(HomepageActivity.this, SekilasActivity.class);
                    startActivity(j);
                }
                else if (i == 1) {
                    Intent j = new Intent(HomepageActivity.this, VMActivity.class);
                    startActivity(j);
                }
                else if (i == 2) {
                    Intent j = new Intent(HomepageActivity.this, SejarahActivity.class);
                    startActivity(j);
                }
            }
        });
    }
}