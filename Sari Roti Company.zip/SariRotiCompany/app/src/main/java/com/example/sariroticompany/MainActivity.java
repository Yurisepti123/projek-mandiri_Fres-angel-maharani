package com.example.sariroticompany;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Animation animasi;
    ImageView logo;
    ImageView head;
    ImageView footer;
    TextView copyright;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        logo = findViewById(R.id.imgLogo);
        head = findViewById(R.id.imgHead);
        footer = findViewById(R.id.imgFooter);
        copyright = findViewById(R.id.copyright);

        animasi();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(MainActivity.this, HomepageActivity.class);
                startActivity(intent);
                finish();
            }
        }, 3000);
    }

    private void animasi() {
        animasi = AnimationUtils.loadAnimation(this, R.anim.splash_animation);
        logo.startAnimation(animasi);
        head.startAnimation(animasi);
        footer.startAnimation(animasi);
        copyright.startAnimation(animasi);
    }
}